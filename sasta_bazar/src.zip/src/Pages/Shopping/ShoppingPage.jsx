import React from 'react'
import Navbar from '../../Components/ShoppingCom/Navbar'

const ShoppingPage = () => {
  return <>
  <Navbar/>
  </>
}

export default ShoppingPage
export const ADD_TO_CART = "ADD_TO_CART";

export const DELETE_TO_CART = "DELETE_TO_CART";

export const ORDERED_PLACED = "ORDERED_PLACED"